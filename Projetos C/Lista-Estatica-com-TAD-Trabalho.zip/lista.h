//Arquivo "lista.h"

//Renomeando as structs
typedef struct PRODUTO produto;
typedef struct LISTA lista;

//Função para criar e alocar memória da lista
lista *criar_lista();

//Função para liberar a memória da lista
void liberar_lista(lista *catalogo);

//Função para acessar o menu da lista
void menu();

//Função para cadastrar um produto na lista
void cadastrar_produtos();

//Função para fazer a busca de um produto na lista
void buscar_menor_preco();

//Função para remover n itens do final da lista
void remover_produtos();

//Função para trocar dois itens de lugar na lista
void trocar_produtos();

//Função para imprimir a lista criada
void imprimir_lista();
