//Arquivo "lista.c"

#include <stdio.h>
#include <stdlib.h>
#include "lista.h"      //implementação do arquivo "lista.h"
#include <unistd.h>

//Definição de um produto
struct PRODUTO {
  int codigo;
  char nome[30];
  float preco;
  int qtd;
};

//Definição da lista de produtos
struct LISTA {
  int tamanho;
  produto catalogo[10];
};

//Alocação da memória para a lista
lista *criar_lista() {
  lista *cat;

  cat = malloc(sizeof(lista));
  cat->catalogo->qtd = 0;

  return cat;
}

//Função para liberar memória da lista
void liberar_lista (lista *catalogo) {
  free(catalogo);
}

//Chamada da função menu para escolher as opções
void menu (int *opcao) {
  printf("--------------------------------------------\n");
  printf("Digite uma opção: \n");
  printf("1. Cadastrar um produto na lista\n");
  printf("2. Buscar o item com menor preço\n");
  printf("3. Remover os últimos n produtos da lista\n");
  printf("4. Trocar as posições de dois itens da lista (de 0 a 10)\n");
  printf("5. Imprimir a lista\n");
  printf("6. Sair\n");
  printf("--------------------------------------------\n");
  scanf("%d", opcao);
}

//Função para cadastrar um produto na lista
void cadastrar_produtos(lista *cat) {
  system("clear");
  int i = cat->tamanho;

  printf("--------------------------------------------\n");
  printf("Código do produto: \n");
  scanf(" %d", &cat->catalogo[i].codigo);
  while (cat->catalogo[i].codigo < 0) {
    printf("Código inválido. Digite novamente: \n");
    scanf(" %d", &cat->catalogo[i].codigo);
  }

  printf("Digite o nome: \n");
  scanf(" %[^\n]", cat->catalogo[i].nome);

  printf("Digite o preço: \n");
  scanf(" %f", &cat->catalogo[i].preco);
  while (cat->catalogo[i].preco < 0) {
    printf("Preço inválido. Digite novamente: \n");
    scanf(" %f", &cat->catalogo[i].preco);
  }

  printf("Digite a quantidade em estoque: \n");
  scanf(" %d", &cat->catalogo[i].qtd);
  while (cat->catalogo[i].qtd < 0) {
    printf("Quantidade inválida. Digite novamente: \n");
    scanf(" %d", &cat->catalogo[i].qtd);
  }

  printf("--------------------------------------------\n");
  printf("PRODUTO CADASTRADO COM SUCESSO!\n");
  sleep(2);

  //Aumento no tamanho da lista
  cat->tamanho++;
  
}

//Função para fazer a busca de um produto na lista
void buscar_menor_preco(lista *cat){
  system("clear");
  int menor_preco;
  int endereco_menor_preco;
  if (cat->tamanho != 0) {
    
    //A partir daqui, o programa percorrerá a lista toda para procurar o produto que possua o menor preço. Para isso, ele irá armazenar o preço do primeiro produto e seu endereço na lista, para comparar com os demais produtos cadastrados na lista
    for (int i=0;i<cat->tamanho;i++) {
      if (i == 0) {
        menor_preco = cat->catalogo[i].preco;
        endereco_menor_preco = i;
      }
      if (cat->catalogo[i].preco < menor_preco) {
        menor_preco = cat->catalogo[i].preco;
        endereco_menor_preco = i;
      }
    }

    //Impressão do resultado após percorrer toda a lista
    printf("--------------------------------------------\n");
    printf("O produto com menor preço é: \n");
    printf("Código: %d\n", cat->catalogo[endereco_menor_preco].codigo);
    printf("Nome: %s\n", cat->catalogo[endereco_menor_preco].nome);
    printf("Preço: %.2f\n", cat->catalogo[endereco_menor_preco].preco);
    printf("Quantidade em estoque: %d\n", cat->catalogo[endereco_menor_preco].qtd);
    printf("--------------------------------------------\n");
    printf("OPERAÇÃO REALIZADA COM SUCESSO!\n");
    sleep(5);
    system("clear");
  }
  else {
    printf("--------------------------------------------\n");
    printf("Não há produtos cadastrados na lista.");
    printf("--------------------------------------------\n");
    sleep(3);
    system("clear");
  }
}

//Função para remover n itens do final da lista
void remover_produtos(lista *cat) {
  system("clear");
  int n;

  printf("Digite quantos itens deseja apagar do final da lista: ");
  scanf("%d", &n);
  while(cat->tamanho < n) {
    printf("A quantidade digitada para ser removida é maior do que a quantidade de itens da lista. Digite um outro número: ");
    scanf("%d", &n);
  }

  cat->tamanho -= n;
  printf("--------------------------------------------\n");
  printf("PRODUTOS REMOVIDOS COM SUCESSO!\n");
  sleep(5);
  system("clear");
}

//Função para trocar dois itens de lugar na lista
void trocar_produtos(lista *cat) {
  system("clear");
  int item_1, item_2;

  produto aux;

  printf("--------------------------------------------\n");
  printf("Digite as duas posições que deseja trocar: ");
  scanf("%d %d", &item_1, &item_2);
  while (cat->tamanho - item_1 < 0 || cat->tamanho - item_2 < 0 || item_1 < 0 || item_2 < 0) {
    printf("Alguma(as) das posições não existe. Digite novamente as duas posições: ");
    scanf("%d %d", &item_1, &item_2);
  }

  //Realiza a troca dos produtos da lista
  aux = cat->catalogo[item_1];
  cat->catalogo[item_1] = cat->catalogo[item_2];
  cat->catalogo[item_2] = aux;

  printf("--------------------------------------------\n");
  printf("OPERAÇÃO REALIZADA COM SUCESSO!\n");
  sleep(5);
  system("clear");
}

//Função para imprimir a lista criada
void imprimir_lista(lista *cat, int numero) { 

  if (numero >= cat->tamanho) {
    return;
  }

  printf("--------------------------------------------\n");
  printf("Código: %d\n", cat->catalogo[numero].codigo);
  printf("Nome: %s\n", cat->catalogo[numero].nome);
  printf("Preço: %.2f\n", cat->catalogo[numero].preco);
  printf("Quantidade em estoque: %d\n", cat->catalogo[numero].qtd);
  printf("--------------------------------------------\n");

  imprimir_lista(cat, numero+1);
}