#include <stdio.h>
#include <stdlib.h>
#include "lista.h"      //implementação do arquivo "lista.h"
#include <unistd.h>

int main(void) {

  int quantidade;
  int opcao = 0;
  int sair = 0;
  int numero = 0;

  lista *catalogo;

  system("clear");

  catalogo = criar_lista();

  //Menu
  do {
    menu(&opcao);
    switch (opcao) {
      
      case 1:
      //Cadastrar um produto
      cadastrar_produtos(catalogo);
      break;

      case 2:
      //Para buscar o item com menor preço
      buscar_menor_preco(catalogo);
      break;

      case 3:
      //Remover os últimos n produtos da lista
      remover_produtos(catalogo);
      break;

      case 4:
      //Trocar a posição de dois produtos na lista
      trocar_produtos(catalogo);
      break;

      case 5:
      //Imprimir a lista
      imprimir_lista(catalogo, numero);
      break;

      case 6:
      //Sair do programa
      printf("Programa encerrado!");
      sair = 1;
      break;

      default:
      //Caso o usuário digite uma opção inválida
      printf("Opção inválida. Digite outra opção: ");
      sleep(2);
      system("clear");
      break;
    }
  } while (sair == 0); //Repetição do menu

  liberar_lista(catalogo); //Libera memória da lista ao sair do programa

  return 0;
}