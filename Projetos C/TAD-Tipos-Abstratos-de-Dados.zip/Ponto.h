  //Arquivo Ponto.h

  //Aqui serão inseridos os nomes, variáveis, protótipos, etc. Tudo o que for global para o programa (acesso a qualquer um)

  typedef struct ponto Ponto;         

  //criar um novo ponto
  Ponto* pto_cria(float x, float y);     //protótipo de função   (fopen)

  //libera um ponto
  void pto_libera (Ponto* p);             //(fclose)

  //Acessar os valores de "x" e "y" de um ponto
  void pto_acessa (Ponto* p, float *x, float *y);          

  //Atribuir os valores de "x" e "y" de um ponto
  void pto_atribui (Ponto* p, float x, float y);

  //calculo da distancia entre os dois pontos
  float pto_distancia (Ponto* p1, Ponto* p2);
