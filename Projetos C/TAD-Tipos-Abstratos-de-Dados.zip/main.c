#include <stdio.h>
#include <stdlib.h>
#include "Ponto.h"

int main(void) {
  system ("clear");
  
  float dist;
  Ponto *p, *q;

  //Criação dos pontos
  p = pto_cria (10, 21);
  q = pto_cria (7, 25);

  //Chamada da função para calcular a distância e impressão do resultado na tela
  dist = pto_distancia(p, q);
  printf("\nA distância entre esses dois pontos é %.2f", dist);

  //Liberação da memória dos pontos
  pto_libera(p);
  pto_libera(q);

  system("pause");

  return 0;
}