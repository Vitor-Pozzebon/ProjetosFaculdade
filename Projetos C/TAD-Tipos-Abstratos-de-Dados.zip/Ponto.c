//Arquivo "Ponto.c"

//Aqui serão inseridos os dados que apenas o programa irá conter (funções)

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Ponto.h"    //Inclui o arquivo com os protótipos das funções

//definição do tipo de dados
struct ponto {
  float x;
  float y;
};

//Alocação e retorno de um ponto com coordenadas "x" e "y"
Ponto* pto_cria (float x, float y) {
  Ponto* p = (Ponto*) malloc (sizeof(Ponto));
  if (p != NULL) {
    p -> x = x;
    p -> y = y;
  }
  return p;
}

//Liberação do espaço de memória do ponto ponto
void pto_libera (Ponto* p) {
  free(p);
}

//Recuperação, por referência, do valor de um ponto
void pto_recupera (Ponto* p, float *x, float *y) {
  *x = p -> x;
  *y = p -> y; 
}

//Atribuir as coordenadas "x" e "y" a um ponto
void pto_atribui (Ponto* p, float x, float y) {
  p -> x = x;
  p -> y = y;
} 

//Cálculo da distância entre os pontos
float pto_distancia (Ponto* p1, Ponto* p2) {
  float dx = p1 -> x - p2 -> x;
  float dy = p1 -> y - p2 -> y;
  return sqrt (dx*dx + dy*dy);
}
